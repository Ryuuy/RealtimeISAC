// 用法（在 DASH_html_old-main 目录下）:  node verify_install.js
// 检查：[1] tos 22 档视频是否装全  [2] tos 的两个 MPD  [3] 本次(10-25)代码文件是否都是新版（对照 CODE_SHA256.txt）
// 只读，不改任何文件。
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const root = process.cwd();
let bad = 0;
const fail = (m) => { bad++; console.log('  ✗ ' + m); };
const ok = (m) => console.log('  ✓ ' + m);

console.log('[1] tos 视频目录');
const tiers = [100,200,300,500,800,1000,1250,1500,1800,2000,2500,3000,3500,4000,5000,6000,7000,8000,10000,12000,16000,20000];
let good = 0, total = 0;
for (const k of tiers) {
  const d = path.join(root, 'tos_2s_1080p', `tos_2s_${k}kbit`);
  if (!fs.existsSync(d)) { fail(`缺目录 tos_2s_1080p/tos_2s_${k}kbit（对应 tos_v1..v4 里哪个 zip 没解压？100–4000=v1, 5000–8000=v2, 10000/12000=v3, 16000/20000=v4）`); continue; }
  const names = new Set(fs.readdirSync(d));
  const missing = [];
  if (!names.has('tos_2sinit.mp4')) missing.push('tos_2sinit.mp4');
  for (let i = 1; i <= 367; i++) if (!names.has(`tos_2s${i}.m4s`)) missing.push(`tos_2s${i}.m4s`);
  let sz = 0; for (const n of names) { try { sz += fs.statSync(path.join(d, n)).size; } catch (e) {} }
  total += sz;
  const mbit = sz * 8 / 734 / 1e6, nom = k / 1000;
  if (missing.length) fail(`${k} kbit 缺 ${missing.length} 个文件，如 ${missing.slice(0,3).join(',')}`);
  else if (Math.abs(mbit - nom) / nom > 0.12) fail(`${k} kbit 体积不对：实测 ${mbit.toFixed(2)} Mbit/s（应≈${nom}）→ 可能解压不全/损坏`);
  else good++;
}
if (good === tiers.length) ok(`22 档全部完整，共 ${(total/1e9).toFixed(2)} GB（应≈9.8 GB）`);

console.log('[2] tos MPD');
for (const f of ['tos_ibmff_mixed_1080p.mpd', 'tos_ibmff_mixed_1080p-public-access.mpd'])
  fs.existsSync(path.join(root, f)) ? ok(f) : fail('缺 ' + f + '（在 DASH_20261025_code.zip 里）');

console.log('[3] 代码文件版本（对照 CODE_SHA256.txt，10-25）');
const sumFile = path.join(root, 'CODE_SHA256.txt');
if (!fs.existsSync(sumFile)) fail('没有 CODE_SHA256.txt（DASH_20261025_code.zip 没解压到这个目录？）');
else {
  let n = 0, same = 0;
  for (const line of fs.readFileSync(sumFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^([0-9a-f]{64})\s+\*?(.+)$/); if (!m) continue;
    n++; const p = path.join(root, m[2]);
    if (!fs.existsSync(p)) { fail('缺 ' + m[2]); continue; }
    const got = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
    if (got === m[1]) same++; else fail(`${m[2]} 不是 10-25 版本（旧版没被覆盖？）`);
  }
  if (same === n) ok(`${n} 个文件全部是 10-25 版本（含 dash-js/fillplan.js）`);
}
console.log(bad ? `\n共 ${bad} 项不通过` : '\n全部通过');
process.exit(bad ? 1 : 0);
